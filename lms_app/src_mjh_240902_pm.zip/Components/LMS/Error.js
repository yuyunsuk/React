export function Error() {
  return (
    <>
      <h1>페이지가 없습니다</h1>
    </>
  );
}
